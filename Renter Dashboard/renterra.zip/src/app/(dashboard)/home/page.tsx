import React from "react";

const Home: React.FC = () => {
  return (
    <div>
      <h1>Adding Charts Here</h1>
    </div>
  );
};

export default Home;
