module.exports = {

"[project]/src/components/forms/Renter-Registration-Form.tsx [app-rsc] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_components_forms_Renter-Registration-Form_tsx_fbfd94ca._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/forms/Renter-Registration-Form.tsx [app-rsc] (ecmascript, next/dynamic entry)");
    });
});
}),

};