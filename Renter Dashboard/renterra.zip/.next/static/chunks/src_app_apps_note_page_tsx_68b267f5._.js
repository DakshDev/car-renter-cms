(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_b3d09006._.js",
  "static/chunks/node_modules_prosemirror-view_dist_index_212d9a9b.js",
  "static/chunks/node_modules_@tiptap_core_dist_fd9f07fc._.js",
  "static/chunks/node_modules_@floating-ui_react_dist_c1a64d8e._.js",
  "static/chunks/node_modules_@tiptap_babe4373._.js",
  "static/chunks/node_modules_@floating-ui_ef84a929._.js",
  "static/chunks/node_modules_@radix-ui_3f3ed513._.js",
  "static/chunks/node_modules_2f1af919._.js",
  "static/chunks/src_components_d38fe899._.css"
],
    source: "dynamic"
});
