(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_1e50081d._.js",
  "static/chunks/src_components_0e1d33a6._.js"
],
    source: "dynamic"
});
